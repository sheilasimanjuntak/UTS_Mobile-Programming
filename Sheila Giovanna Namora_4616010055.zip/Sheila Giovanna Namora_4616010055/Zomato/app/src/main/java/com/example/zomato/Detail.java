package com.example.zomato;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class Detail extends AppCompatActivity {

    private static final String TAG = "DetailActivity";

    private TextView mTitle, mAddress, mType, mHours, mRating;
    private ImageView mImage;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        initView();
        setData();
    }

    public void initView() {
        mContext = getApplicationContext();
        mImage = findViewById(R.id.imageDetail);
        mTitle = findViewById(R.id.textDetailTitle);
        mAddress = findViewById(R.id.textDetailAddress);
        mType = findViewById(R.id.textDetailType);
        mHours = findViewById(R.id.textDetailHours);
        mRating = findViewById(R.id.textDetailRating);
    }

    public void setData(){

        Intent i = getIntent();
        String address = i.getStringExtra("ALAMAT_RESTO");
        String hours = i.getStringExtra("JAMBUKA_RESTO");
        String type = i.getStringExtra("JENISMAKANAN_RESTO");
//        String approx = i.getStringExtra("PERKIRAANMAKANAN_RESTO");
        String urlimg = i.getStringExtra("URLIMG_RESTO");
        String rating = i.getStringExtra("RATING_RESTO");
        String title = i.getStringExtra("NAMA_RESTO");
        mAddress.setText(address);
        mTitle.setText(title);
        mHours.setText(hours);
        mType.setText(type);
//        .setText(jambuka);
        mRating.setText(rating);

        Glide.with(mContext)
                .asBitmap()
                .load(urlimg)
                .into(mImage);

    }
}
