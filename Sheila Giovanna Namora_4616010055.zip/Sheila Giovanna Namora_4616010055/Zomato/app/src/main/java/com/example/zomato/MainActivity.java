package com.example.zomato;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;

import android.content.Context;
import android.content.Intent;

import com.example.zomato.Adapter.RecyclerViewAdapter;
import com.example.zomato.Model.Category;

import java.util.List;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.OnViewClick {

    private static final String TAG = "MainActivity";

    private RecyclerViewAdapter mAdapter;
    private RecyclerView mRecycler;
    private Context mContext;
    private List<Category> mCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = getApplicationContext();
        initRecycler();
    }

    public void initRecycler(){
        mCategory = DataSource.createCategoryList();
        mRecycler = findViewById(R.id.recyclerView);
        mRecycler.setHasFixedSize(true);
        mRecycler.setLayoutManager(new LinearLayoutManager(this));
        mAdapter = new RecyclerViewAdapter(mContext, mCategory, this);
        mRecycler.setAdapter(mAdapter);

    }

    @Override
    public void onViewClick(int position) {
        Log.d(TAG, "onViewClick: " + position);
        Category category = mCategory.get(position);
        Log.d(TAG, "onViewClick: " + category.getTitle());

        Intent i = new Intent(MainActivity.this, GridActivity.class);
        i.putExtra("TITLE_CAT", category.getTitle());
        i.putExtra("OUTLET_CAT", category.getOutlet());
        i.putExtra("DESC_CAT",category.getDesc());
        i.putExtra("URL_CAT",category.getUrl());
        startActivity(i);
    }

}

