package com.example.zomato.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import com.example.zomato.Model.Restaurant;
import com.example.zomato.R;

import java.util.List;

public class GridRecyclerAdapter extends RecyclerView.Adapter<GridRecyclerAdapter.ViewHolder> {
    private static final String TAG = "NotesRecyclerAdapter";

    private Context mContext;
    private List<Restaurant> mRestaurant;
    private OnViewClick mOnViewClick;

    public GridRecyclerAdapter(Context mContext, List<Restaurant> mRestaurant, OnViewClick mOnViewClick) {
        this.mContext = mContext;
        this.mRestaurant = mRestaurant;
        this.mOnViewClick = mOnViewClick;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_card_layout, parent, false);
        return new ViewHolder(view, mOnViewClick);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Restaurant restaurant = mRestaurant.get(position);
        holder.restTitle.setText(restaurant.getRestTitle());
        holder.restAddress.setText(restaurant.getRestAddress());
        holder.restType.setText(restaurant.getRestType());
        holder.restRating.setText(restaurant.getRestRating());

//        RequestOptions myOptions = new RequestOptions()
//                .override(125, 125);

        Glide.with(mContext)
                .asBitmap()
//                .apply(myOptions)
                .load(restaurant.getUrlImage())
                .into(holder.image);
    }

    @Override
    public int getItemCount() {
        return mRestaurant.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView restTitle;
        TextView restAddress;
        TextView restType;
        TextView restApprox;
        TextView restRating;
        //        TextView restHours;
        ImageView image;
        OnViewClick mOnViewClick;

        ViewHolder(View itemView, OnViewClick onViewClick) {
            super(itemView);
            restTitle = itemView.findViewById(R.id.textGridTitle);
            restAddress = itemView.findViewById(R.id.textGridAddress);
            restType = itemView.findViewById(R.id.textGridType);
            restApprox = itemView.findViewById(R.id.textGridApprox);
            restRating = itemView.findViewById(R.id.textGridRating);
//            jamBuka = itemView.findViewById(R.id.gri);
            image = itemView.findViewById(R.id.imageGridImage);
            mOnViewClick = onViewClick;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Log.d(TAG, "onClick: " + getAdapterPosition());
            mOnViewClick.onViewClick(getAdapterPosition());
        }
    }

    public interface OnViewClick {
        void onViewClick(int position);
    }

}


