package com.example.zomato.Model;

public class Category {

    private String title;
    private String outlet;
    private String desc;
    private String url;

    public Category (String title, String outlet, String desc, String url){
        this.title = title;
        this.outlet = outlet;
        this.desc = desc;
        this.url = url;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public String getOutlet(){
        return outlet;
    }

    public void setOutlet(String outlet){
        this.outlet = outlet;
    }

    public String getDesc(){
        return desc;
    }

    public void setDesc(String desc){
        this.desc = desc;
    }

    public String getUrl(){
        return url;
    }

    public void setUrl(String outlet){
        this.url = url;
    }
}

