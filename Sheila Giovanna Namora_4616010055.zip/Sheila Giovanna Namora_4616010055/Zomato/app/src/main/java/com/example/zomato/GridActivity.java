package com.example.zomato;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.zomato.Adapter.GridRecyclerAdapter;
import com.example.zomato.Model.Restaurant;

import java.util.List;

public class GridActivity extends AppCompatActivity implements GridRecyclerAdapter.OnViewClick {

    private static final String TAG = "GridActivity";

    private ImageView mImageCategory;
    private Context mContext;
    private TextView mTitle, mOutlet, mDesc;
    private GridRecyclerAdapter mAdapter;
    private RecyclerView mRecycler;
    private List<Restaurant> mRestaurant;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        initView();
        setData();
        initRecycler();
    }

    public void initRecycler(){
        mRestaurant = DataSource.createRestaurantList();
        mRecycler = findViewById(R.id.gridRecyclerView);
        mRecycler.setHasFixedSize(true);
        mRecycler.setLayoutManager(new GridLayoutManager(this, 2));
        mAdapter = new GridRecyclerAdapter(mContext, mRestaurant,this);
        mRecycler.setAdapter(mAdapter);

    }

    public void initView(){
        mContext = getApplicationContext();
        mImageCategory = findViewById(R.id.imageCategory);
        mTitle = findViewById(R.id.textCategoryTitle);
        mOutlet = findViewById(R.id.textCategoryDesc);
        mDesc = findViewById(R.id.textCategoryCapt);
    }

    public void setData(){
        Intent i = getIntent();
        String title = i.getStringExtra("TITLE_CAT");
        String outlet = i.getStringExtra("OUTLET_CAT");
        String desc = i.getStringExtra("DESC_CAT");
        mTitle.setText(title);
        mOutlet.setText(outlet);
        mDesc.setText(desc);

        Glide.with(mContext)
                .asBitmap()
                .load(i.getStringExtra("URL_CAT"))
                .into(mImageCategory);

    }

    @Override
    public void onViewClick(int position) {
        Log.d(TAG, "onViewClick: " + position);
        Restaurant restoran = mRestaurant.get(position);
        Log.d(TAG, "onViewClick: " + restoran.getRestTitle());

        Intent i = new Intent(GridActivity.this, Detail.class);
        i.putExtra("ALAMAT_RESTO", restoran.getRestAddress());
        i.putExtra("JAMBUKA_RESTO", restoran.getRestHours());
        i.putExtra("JENISMAKANAN_RESTO",restoran.getRestType());
        i.putExtra("PERKIRAANMAKANAN_RESTO",restoran.getRestApprox());
        i.putExtra("URLIMG_RESTO",restoran.getUrlImage());
        i.putExtra("RATING_RESTO",restoran.getRestRating());
        i.putExtra("NAMA_RESTO",restoran.getRestTitle());
        startActivity(i);
    }

}
