package com.example.zomato.Model;

public class Restaurant {

    private String restTitle;
    private String restAddress;
    private String restType;
    private String restApprox;
    private String restRating;
    private String restHours;
    private String urlImage;

    public Restaurant(String restTitle, String restAddress, String restType, String restApprox, String restHours, String restRating, String urlImage){
        this.restTitle = restTitle;
        this.restAddress = restAddress;
        this.restType = restType;
        this.restApprox = restApprox;
        this.restHours = restHours;
        this.restRating = restRating;
        this.urlImage = urlImage;
    }

    public String getRestTitle(){
        return restTitle;
    }

    public void setRestTitle(){
        this.restTitle = restTitle;
    }

    public String getRestAddress(){
        return restAddress;
    }

    public void setRestAddress(){
        this.restAddress = restAddress;
    }

    public String getRestType(){
        return restType;
    }

    public void setRestType(){
        this.restType = restType;
    }

    public String getRestApprox(){
        return restApprox;
    }

    public void setRestApprox(){
        this.restApprox = restApprox;
    }

    public String getRestHours(){
        return restHours;
    }

    public void setRestHours(){
        this.restHours = restHours;
    }

    public String getRestRating(){
        return restRating;
    }

    public void setRestRating(){
        this.restRating = restRating;
    }

    public String getUrlImage(){
        return urlImage;
    }

    public void setUrlImage(){
        this.urlImage = urlImage;
    }
}
